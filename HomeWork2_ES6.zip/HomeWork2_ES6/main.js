document.addEventListener('DOMContentLoaded', function() {
   let clockCalendar = new MakeItWork();

      clockCalendar.attachEvents();
      clockCalendar.keepThePermanentState();
     
}, false);
