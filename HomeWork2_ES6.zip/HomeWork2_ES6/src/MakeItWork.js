'use strict'

class MakeItWork {
	constructor() {
       
    this.clockCalendar = new ClockCalendar();
	}

	attachEvents() {
    let container = this.clockCalendar.container;
		   container.addEventListener('click', () => this.clockCalendar.clickOnTheLeft(), false);

      container.addEventListener('contextmenu', (event) => {
        event.preventDefault();
        this.clockCalendar.clickOnTheRight();
    }); 
	}
  keepThePermanentState() {
        this.clockCalendar.updateClockCalendar();
        this.clockCalendar.makeIntervals();
    }
  


}
