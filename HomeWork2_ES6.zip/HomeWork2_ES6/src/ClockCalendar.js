'use strict'

class ClockCalendar {
	constructor() {
	  this.currentState = 'clock';
	  this.clockFormat = 'HH:MM';
	  this.dateFormat = 'DD.MM.YYYY';
      this.container = document.querySelector('.clock-calendar');
      this.currentValue;
	}

    

    getClockCalendarValue() {
	    let result;

 	    if (this.currentState === 'clock') {
	      result = this.getTime(this.clockFormat);
	    } else if (this.currentState === 'calendar') {
	      result = this.getDate(this.dateFormat);
	    }
		
	    return result;  
    }
    
    getTime() {
	    let date = new Date();	
        let hours = date.getHours();
            hours = hours < 10 ? '0' + hours: hours;
        let minutes = date.getMinutes();
            minutes = minutes < 10 ? '0' + minutes: minutes;
        let seconds = date.getSeconds();
            seconds = seconds < 10 ? '0' + seconds: seconds;
  
        let colon = ':';
        let result;
        if (this.clockFormat === 'HH:MM') {
		result = hours + colon + minutes;
        } else {
		result = hours +colon + minutes + colon + seconds;
        }
	
	return result;
   }

   getDate() {
	    let date = new Date();
        let dayNum = date.getDate();
        let month = date.getMonth()+1;
        let year  = date.getFullYear();
        let date_UA = date.toLocaleDateString('uk', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
        let date_EU = date.toLocaleDateString('en-EU', {
            day: '2-digit',
            month: '2-digit',
            year: '2-digit'
        });

        let result;
        if(this.dateFormat === 'DD.MM.YYYY'){
          result = date_UA;
        } else if(this.dateFormat === 'MM/DD/YY'){
          result = date_EU;
        }

        return result;

    }

    clickOnTheLeft() {
        if (this.currentState === 'clock') {
          this.clockFormat = this.clockFormat === 'HH:MM' ? 'HH:MM:SS' : 'HH:MM';
        } else if (this.currentState === 'calendar') {
          this.dateFormat = this.dateFormat === 'DD.MM.YYYY' ? 'MM/DD/YY' : 'DD.MM.YYYY';
        }
        this.updateClockCalendar();
    }

    clickOnTheRight(event) {
        if (this.currentState === 'clock') {
          this.currentState = 'calendar';
          this.dateFormat = 'DD.MM.YYYY';
        } else if (this.currentState === 'calendar') {
          this.currentState = 'clock';
          this.clockFormat = 'HH:MM';
        }
        this.updateClockCalendar();
    }

    updateClockCalendar() {
      let currentValue = this.getClockCalendarValue();

      if (currentValue !== this.container.innerHTML) {
        this.container.innerHTML = currentValue;
      }
  }
    makeIntervals() {
       setInterval(() => this.updateClockCalendar(), 1000);
  }

}
